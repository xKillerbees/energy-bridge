package com.example.energybridge;

import com.example.energybridge.content.EnergyBridgeBE;
import com.example.energybridge.registry.ModRegistries;
import net.minecraft.core.Direction;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.capabilities.Capabilities;
import net.neoforged.neoforge.capabilities.RegisterCapabilitiesEvent;

@EventBusSubscriber(modid = EnergyBridgeMod.MODID, bus = EventBusSubscriber.Bus.MOD)
public final class ModCapabilities {
    private ModCapabilities() {}

    @SubscribeEvent
    public static void onRegisterCapabilities(RegisterCapabilitiesEvent event) {
        // Hide energy capability from external HUDs like Jade by not exposing it.
        // The bridge still WORKS because it actively pushes to neighbors (UP/DOWN)
        // and pulls from sides in its server tick.
        event.registerBlockEntity(
                Capabilities.EnergyStorage.BLOCK,
                ModRegistries.ENERGY_BRIDGE_BE.get(),
                (EnergyBridgeBE be, Direction side) -> null
        );
    }
}