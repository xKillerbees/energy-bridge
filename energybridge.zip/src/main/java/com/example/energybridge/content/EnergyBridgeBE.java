package com.example.energybridge.content;

import com.example.energybridge.registry.ModRegistries;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.neoforged.neoforge.capabilities.Capabilities;
import net.neoforged.neoforge.energy.EnergyStorage;
import net.neoforged.neoforge.energy.IEnergyStorage;

public class EnergyBridgeBE extends BlockEntity {

    public static final int CAPACITY = 200_000;
    public static final int MAX_IN = 20_000;
    public static final int MAX_OUT = 20_000;

    private final EnergyStorage buffer = new EnergyStorage(CAPACITY, MAX_IN, MAX_OUT);

    public EnergyBridgeBE(BlockPos pos, BlockState state) {
        super(ModRegistries.ENERGY_BRIDGE_BE.get(), pos, state);
    }

    @Override
    protected void saveAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.saveAdditional(tag, registries);
        tag.putInt("fe", buffer.getEnergyStored());
    }

    @Override
    protected void loadAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.loadAdditional(tag, registries);
        int v = tag.getInt("fe");
        int missing = CAPACITY - buffer.getEnergyStored();
        if (missing > 0 && v > 0) buffer.receiveEnergy(Math.min(missing, v), false);
    }

    public static void serverTick(Level level, BlockPos pos, BlockState state, EnergyBridgeBE be) {
        if (level.isClientSide) return;

        boolean pulled = false;
        boolean pushed = false;

        // Pull from horizontal neighbors (N/S/E/W)
        for (Direction dir : new Direction[]{Direction.NORTH, Direction.SOUTH, Direction.EAST, Direction.WEST}) {
            IEnergyStorage neighbor = level.getCapability(Capabilities.EnergyStorage.BLOCK, pos.relative(dir), dir.getOpposite());
            if (neighbor != null && neighbor.canExtract()) {
                int space = be.buffer.getMaxEnergyStored() - be.buffer.getEnergyStored();
                int toPull = Math.min(MAX_IN, space);
                if (toPull > 0) {
                    int n = neighbor.extractEnergy(toPull, false);
                    if (n > 0) { be.buffer.receiveEnergy(n, false); pulled = true; }
                }
            }
        }

        // Push only to UP and DOWN
        if (be.buffer.getEnergyStored() > 0) {
            for (Direction dir : new Direction[]{Direction.UP, Direction.DOWN}) {
                IEnergyStorage neighbor = level.getCapability(Capabilities.EnergyStorage.BLOCK, pos.relative(dir), dir.getOpposite());
                if (neighbor != null && neighbor.canReceive()) {
                    int toSend = Math.min(MAX_OUT, be.buffer.getEnergyStored());
                    int sent = neighbor.receiveEnergy(toSend, false);
                    if (sent > 0) { be.buffer.extractEnergy(sent, false); pushed = true; }
                }
            }
        }

        // Light ring only when there was activity this tick (pull OR push).
        boolean shouldBeLit = pulled || pushed;
        if (state.hasProperty(EnergyBridgeBlock.LIT) && state.getValue(EnergyBridgeBlock.LIT) != shouldBeLit) {
            level.setBlockAndUpdate(pos, state.setValue(EnergyBridgeBlock.LIT, shouldBeLit));
        }
    }
}