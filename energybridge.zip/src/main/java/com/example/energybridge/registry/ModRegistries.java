package com.example.energybridge.registry;

import com.example.energybridge.EnergyBridgeMod;
import com.example.energybridge.content.EnergyBridgeBE;
import com.example.energybridge.content.EnergyBridgeBlock;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

public final class ModRegistries {
    private ModRegistries() {}

    public static final DeferredRegister<Block> BLOCKS =
            DeferredRegister.create(Registries.BLOCK, EnergyBridgeMod.MODID);
    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(Registries.ITEM, EnergyBridgeMod.MODID);
    public static final DeferredRegister<BlockEntityType<?>> BLOCK_ENTITIES =
            DeferredRegister.create(Registries.BLOCK_ENTITY_TYPE, EnergyBridgeMod.MODID);

    public static final DeferredHolder<Block, EnergyBridgeBlock> ENERGY_BRIDGE = BLOCKS.register(
            "energy_bridge",
            () -> new EnergyBridgeBlock(Block.Properties.of()
                    .strength(2.5F, 6.0F)
                    .requiresCorrectToolForDrops()
                    .lightLevel(state -> state.hasProperty(EnergyBridgeBlock.LIT) && state.getValue(EnergyBridgeBlock.LIT) ? 8 : 0)
            )
    );

    public static final DeferredHolder<Item, BlockItem> ENERGY_BRIDGE_ITEM = ITEMS.register(
            "energy_bridge", () -> new BlockItem(ENERGY_BRIDGE.get(), new Item.Properties())
    );

    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<EnergyBridgeBE>> ENERGY_BRIDGE_BE =
            BLOCK_ENTITIES.register("energy_bridge",
                    () -> BlockEntityType.Builder.of(EnergyBridgeBE::new, ENERGY_BRIDGE.get()).build(null));

    public static void register(IEventBus bus) {
        BLOCKS.register(bus);
        ITEMS.register(bus);
        BLOCK_ENTITIES.register(bus);
    }
}