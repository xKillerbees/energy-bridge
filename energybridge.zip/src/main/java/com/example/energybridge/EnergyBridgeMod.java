
package com.example.energybridge;

import com.example.energybridge.registry.ModRegistries;
import net.neoforged.fml.common.Mod;
import net.neoforged.bus.api.IEventBus;

@Mod(EnergyBridgeMod.MODID)
public class EnergyBridgeMod {
    public static final String MODID = "energybridge";

    // 1.21+: NeoForge injects IEventBus into the @Mod constructor.
    public EnergyBridgeMod(IEventBus modBus) {
        ModRegistries.register(modBus);
    }
}
